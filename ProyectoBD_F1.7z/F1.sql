CREATE TABLE piloto (
	nombre_piloto varchar(40),
	fecha_nacimiento date NOT NULL,
	numero_poles integer(10),
	puntos_totales integer(10),
	numero_podios integer(10),
	año_debut_piloto integer(10), NOT NULL
	victorias integer(10),
	grandes_premios_disputados integer(10),
	numero_mundiales_ganados integer(10),
	año_campeon	integer(5),
	nacionalidad_piloto	varchar(40) NOT NULL		
);

ALTER TABLE ONLY piloto
	ADD CONSTRAINT pk_nombre_piloto PRIMARY KEY (nombre_piloto);

CREATE TABLE dorsal (
	dorsal_piloto integer(5),
	nombre_piloto_dorsal varchar(50),
	nombre_piloto varchar (40)
);

ALTER TABLE ONLY dorsal
	ADD CONSTRAINT pk_nombre_piloto_dorsal PRIMARY KEY (nombre_piloto_dorsal);

ALTER TABLE ONLY dorsal
	ADD CONSTRAINT fk_nombre_piloto FOREIGN KEY (nombre_piloto);

CREATE TABLE escuderia (
	nombre_escuderia varchar(10),
	numero_campeonatos_ganados integer(5),
	puntos_totales integer(10),
	nacionalidad_escuderia  varchar(25) NOT NULL,
	año_debut_escuderia integer(10) NOT NULL
);

ALTER TABLE ONLY escuderia
	ADD CONSTRAINT pk_nombre_escuderia PRIMARY KEY (nombre_escuderia);

CREATE TABLE circuitos (
	nombre_circuito varchar(25),
	ciudad varchar(25) NOT NULL,
	record varchar(20) NOT NULL UNIQUE,
	km/vuelta integer(15) NOT NULL, 
	año_debut_circuito integer(15) NOT NULL,
	numero_veces_usado integer(10)
);

ALTER TABLE ONLY circuitos 
	ADD CONSTRAINT pk_nombre_circuito PRIMARY KEY (nombre_circuito);

CREATE TABLE gran_premio (
	nombre_gp varchar(50), 
	pole_position varchar(25) NOT NULL,
	vuelta_rapida integer(20) NOT NULL,
	ganador varchar(20) NOT NULL,
	nombre_circuito varchar (25)
);

ALTER TABLE ONLY gran_premio
	ADD CONSTRAINT pk_nombre_gp PRIMARY KEY (nombre_gp);

ALTER TABLE ONLY gran_premio
	ADD CONSTRAINT fk_nombre_circuito FOREIGN KEY (nombre_circuito);

CREATE TABLE mundial(
	id_mundial integer(30),
	año_mundial integer(10) NOT NULL
);	

ALTER TABLE ONLY mundial
	ADD CONSTRAINT pk_id_mundial PRIMARY KEY (id_mundial);

CREATE TABLE mundial_pilotos (
	nombre_piloto_ganador varchar(20),
	puntos_ganados integer(20) NOT NULL,
	nombre_escuderia varchar(20) NOT NULL,
	año_piloto_ganador integer(10) NOT NULL,
	nombre_piloto varchar(40)
);

ALTER TABLE ONLY mundial_pilotos
	ADD CONSTRAINT pk_nombre_piloto_ganador PRIMARY KEY (nombre_piloto_ganador);

ALTER TABLE ONLY mundial_pilotos
	ADD CONSTRAINT fk_nombre_piloto FOREIGN KEY (nombre_piloto);
 
CREATE TABLE mundial_escuderias (
	nombre_escuderia_ganadora varchar(25),
	año_escuderia_ganadora integer(10) NOT NULL,
	puntos integer(15) NOT NULL,
	nombre_escuderia varchar(15)
);

ALTER TABLE ONLY mundial_escuderias
	ADD CONSTRAINT pk_nombre_escuderia_ganadora PRIMARY KEY (nombre_escuderia_ganadora);

ALTER TABLE ONLY mundial_escuderias
	ADD CONSTRAINT fk_nombre_escuderia FOREIGN KEY (nombre_escuderia);

CREATE TABLE tipo_circuito (
	id_tipo integer(25),
	nombre_circuito varchar(30)
);

ALTER TABLE ONLY tipo_circuito
	ADD CONSTRAINT pk_id_tipo PRIMARY KEY (id_tipo);

ALTER TABLE ONLY tipo_circuito
	ADD CONSTRAINT fk_nombre_circuito FOREIGN KEY (nombre_circuito);

CREATE TABLE autodromo (
	id_tipo integer(25)
);

ALTER TABLE ONLY autodromo
	ADD CONSTRAINT pk_id_tipo PRIMARY KEY (id_tipo);

ALTER TABLE ONLY autodromo
	ADD CONSTRAINT fk_id_circuito FOREIGN KEY (id_circuito);

CREATE TABLE hibrido (
	id_tipo integer(25)
);

ALTER TABLE ONLY hibrido
	ADD CONSTRAINT pk_id_tipo PRIMARY KEY (id_tipo);

ALTER TABLE ONLY hibrido
	ADD CONSTRAINT fk_id_circuito FOREIGN KEY (id_circuito);


CREATE TABLE urbano (
	id_tipo integer(25)
);

ALTER TABLE ONLY urbano
	ADD CONSTRAINT pk_id_tipo PRIMARY KEY (id_tipo);

ALTER TABLE ONLY urbano
	ADD CONSTRAINT fk_id_circuito FOREIGN KEY (id_circuito);

CREATE TABLE pertenece (
	nombre_piloto integer(40),
	nombre_escuderia varchar(40),
	nombre_gp integer(25)
);

ALTER TABLE ONLY pertenece
	ADD CONSTRAINT pk_nombre_piloto PRIMARY KEY (nombre_piloto);

ALTER TABLE ONLY pertenece
	ADD CONSTRAINT pk_nombre_escuderia PRIMARY KEY (nombre_escuderia);
	
ALTER TABLE ONLY pertenece
	ADD CONSTRAINT fk_nombre_piloto FOREIGN KEY (nombre_piloto);

ALTER TABLE ONLY pertenece
	ADD CONSTRAINT fk_nombre_escuderia FOREIGN KEY (nombre_escuderia);	

ALTER TABLE ONLY pertenece
	ADD CONSTRAINT fk_nombre_gp FOREIGN KEY (nombre_gp);

CREATE TABLE podio (
	año_podio integer(25),
	id_podio integer(20)
);

ALTER TABLE ONLY podio
	ADD CONSTRAINT pk_año_podio PRIMARY KEY (nombre_podio);
	
ALTER TABLE ONLY podio
	ADD CONSTRAINT pk_id_podio PRIMARY KEY (id_podio);

ALTER TABLE ONLY podio
	ADD CONSTRAINT fk_nombre_gp FOREIGN KEY (nombre_gp);